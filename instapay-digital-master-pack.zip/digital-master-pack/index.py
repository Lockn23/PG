"""
index.py — Vercel Serverless Handler for InstaPay
Bridges the Django WSGI app to Vercel's serverless environment.

Deploy steps:
1. Set environment variables in Vercel dashboard:
   - DJANGO_SECRET_KEY
   - BEYONIC_API_KEY
   - DATABASE_URL (use Vercel Postgres or Supabase)
   - DJANGO_DEBUG (set to "False" for production)

2. Push to GitHub → Vercel auto-deploys
"""

import os
import sys

# Add project root to path
sys.path.insert(0, os.path.dirname(__file__))

# Point Django to the right settings module
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'quickPay.settings')

# Bootstrap Django
import django
django.setup()

# Import the WSGI application
from quickPay.wsgi import application

# Vercel expects a handler function
def handler(request, context):
    """
    Vercel serverless function handler.
    Wraps Django's WSGI application for serverless execution.
    """
    return application(request, context)
